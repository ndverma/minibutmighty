<?php

    echo "once finalist are declared you can access only this finalist page";

?>
